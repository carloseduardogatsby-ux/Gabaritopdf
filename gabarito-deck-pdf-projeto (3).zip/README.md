# Gabarito Deck PDF

Leitor de PDF de provas com gabarito, pincel, marca-texto, borracha e resultado.

## Gerar o APK
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta (branch `main`).
2. Abra a aba **Actions** > **Build APK** (roda sozinho a cada envio; ou clique em *Run workflow*).
3. Ao terminar, baixe o arquivo **Gabarito-Deck-PDF-APK-debug** em *Artifacts* e instale o `app-debug.apk`.

## Gabarito
Formato: `PROVA|NOME|TOTAL|GABARITO` — use `*` para questão nula (anulada).
Exemplo: `PROVA|URCA 2026.1|10|ABCDE*ABCD`

## Paralelo ao app antigo
Usa o ID `com.carlos.leitorgabarito`, então instala ao lado do Gabarito Deck original sem substituí-lo.

## Cor do PDF
Botão 🎨 no leitor alterna entre papel branco e magenta suave.

## Leitor (novidades)
- **Pincéis em Ilha ou Círculo:** em ⚙ > Posição dos pincéis. O círculo fica no canto inferior esquerdo; o botão do canto vira a mão em repouso e a cor quando há ferramenta ativa.
- **Ilha:** toque no ≡ para recolher em um quadrado 1x1; arraste o ≡ para mover.
- **PDF em tela cheia:** em ⚙ (um botão ⚙ pequeno fica no canto quando a barra some).
- **Cor do PDF:** 🎨 magenta, 🌙 modo preto (inverte o PDF), ou escolha em ⚙ > Cor do PDF.

## Instalar junto com o app antigo
- App antigo: `com.carlos.gabaritodeck` (Gabarito Deck). Este: `com.carlos.leitorgabarito` (Gabarito Deck PDF). IDs diferentes, então os dois ficam instalados ao mesmo tempo, cada um com seus próprios dados.
- O arquivo `debug.keystore` fixa a assinatura de todo APK gerado aqui. Assim, cada novo build atualiza o Gabarito Deck PDF por cima, sem desinstalar e sem perder as provas. Não apague esse arquivo.
