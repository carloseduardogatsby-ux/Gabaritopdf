# App Acoci

App do Assentamento Acoci (Campos Sales, CE): preços do dia, mapa com satélite, previsão de chuva, máquinas da associação, botão de emergência e painel da administração.

## Como gerar o APK no GitHub

1. Crie um repositório novo no GitHub (pode ser privado).
2. Envie os arquivos desta pasta para ele (**Add file > Upload files**): `www` (com o `index.html`), `package.json`, `capacitor.config.json` e `.gitignore`.
3. Crie a receita do APK pelo próprio site: clique em **Add file > Create new file**, no nome digite exatamente `.github/workflows/apk.yml` (ao digitar as barras, o GitHub cria as pastas), abra o arquivo `apk.yml` deste zip, copie todo o conteúdo, cole na página e clique em **Commit changes**.
4. Abra a aba **Actions**, escolha **Gerar APK** e clique em **Run workflow**.
5. Espere uns 5 a 10 minutos. Ao terminar, abra a execução e baixe **acoci-apk** (fica no fim da página, em "Artifacts").
6. Descompacte e instale o `app-debug.apk` no celular (o Android vai pedir para permitir instalar de fontes desconhecidas).

Toda vez que você mudar o `www/index.html` e enviar para o GitHub, o APK é gerado de novo.

## O que tem aqui

- `www/index.html`: o app inteiro (tela, mapa, regras).
- `capacitor.config.json`, `package.json`: configuração para transformar em app Android.
- `apk.yml`: receita que o GitHub usa para gerar o APK (você cola no site, no passo 3).

## Importante: este app ainda está em modo demonstração

- Usuários, preços, agenda das máquinas e alertas ficam **só no próprio celular**. Um alerta de emergência **não chega** em outro aparelho. Antes de usar de verdade, é preciso ligar o app a um servidor (ex.: Supabase) e a notificações push.
- O usuário `000` e a senha `alfa` da administração estão escritos dentro do código, só para demonstração. No app real isso não pode ficar assim.
- A lista de números de assentado (101 a 104) é de teste. Fica no trecho `ALLOWED` do `www/index.html`.
- Os preços, as máquinas, as reservas e os valores da hora que aparecem como "exemplo" são inventados.
- O botão SOS **não substitui** ligar para o SAMU (192).
- O APK gerado é de teste (debug). Para publicar na Play Store é preciso assinar o app.
- A imagem de satélite (Esri) e a previsão de chuva (Open-Meteo) precisam de internet.
