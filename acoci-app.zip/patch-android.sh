#!/usr/bin/env bash
# Adiciona as permissões do Android (localização, câmera, notificações, vibração)
set -e
M=android/app/src/main/AndroidManifest.xml
for P in ACCESS_FINE_LOCATION ACCESS_COARSE_LOCATION CAMERA POST_NOTIFICATIONS VIBRATE; do
  if ! grep -q "android.permission.$P" "$M"; then
    sed -i "s#<application#<uses-permission android:name=\"android.permission.$P\"/><application#" "$M"
  fi
done
echo "Permissões conferidas:"; grep -o 'android.permission.[A-Z_]*' "$M" | sort -u
