# Gabarito Deck PDF

Leitor de PDF de provas com gabarito, pincel, marca-texto, borracha e resultado.

## Gerar o APK
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta (branch `main`).
2. Abra a aba **Actions** > **Build APK** (roda sozinho a cada envio; ou clique em *Run workflow*).
3. Ao terminar, baixe o arquivo **Gabarito-Deck-PDF-APK-debug** em *Artifacts* e instale o `app-debug.apk`.

## Gabarito
Formato: `PROVA|NOME|TOTAL|GABARITO` — use `*` para questão nula (anulada).
Exemplo: `PROVA|URCA 2026.1|10|ABCDE*ABCD`

## Paralelo ao app antigo
Usa o ID `com.carlos.leitorgabarito`, então instala ao lado do Gabarito Deck original sem substituí-lo.

## Cor do PDF
Botão 🎨 no leitor alterna entre papel branco e magenta suave.

## Leitor (novidades)
- **Pincéis em Ilha ou Círculo:** em ⚙ > Posição dos pincéis. O círculo fica no canto inferior esquerdo; o botão do canto vira a mão em repouso e a cor quando há ferramenta ativa.
- **Ilha:** toque no ≡ para recolher em um quadrado 1x1; arraste o ≡ para mover.
- **PDF em tela cheia:** em ⚙ (um botão ⚙ pequeno fica no canto quando a barra some).
- **Cor do PDF:** 🎨 magenta, 🌙 modo preto (inverte o PDF), ou escolha em ⚙ > Cor do PDF.

## Instalar junto com o app antigo
- App antigo: `com.carlos.gabaritodeck` (Gabarito Deck). Este: `com.carlos.leitorgabarito` (Gabarito Deck PDF). IDs diferentes, então os dois ficam instalados ao mesmo tempo, cada um com seus próprios dados.
- O arquivo `debug.keystore` fixa a assinatura de todo APK gerado aqui. Assim, cada novo build atualiza o Gabarito Deck PDF por cima, sem desinstalar e sem perder as provas. Não apague esse arquivo.

## Novidades desta versão
- **Tema do app (tela inicial):** Branco, Preto, Azul, Verde, Roxo, Magenta e Sépia. A escolha fica salva.
- **Barra de cima do leitor (2 linhas):** 🎨 cor do PDF, 🌙 modo preto, 🔍 lupa, 📏 réguas, − e + de zoom, ⚙ configurações.
- **Cor do PDF + intensidade:** Branco, Magenta, Sépia, Menta, Azul, Lavanda, Cinza e Preto, com controle de intensidade (no modo preto controla o brilho).
- **Zoom com dois dedos** (pinça) e botões − e +.
- **Lupa:** arraste a lente sobre o texto; toque na lente para trocar o aumento (2x, 2,75x, 3,5x, 4x).
- **Réguas:** faixa de leitura (arraste a alça azul; altura e escurecimento ajustáveis) e linha reta para caneta e marcador.
- **Número da questão na ilha:** abre a lista de questões com filtros Todas, Acertadas, Erradas, Anuladas, Rever e Pendentes.
- Mais cores de caneta (12) e de marcador (8).

## Régua de desenho
- 📏 > Régua de desenho. Régua com marcações em cm e mm, nas duas bordas.
- Arraste para mover. Gire com dois dedos ou com a bolinha azul (encaixa em 0°, 45°, 90° e 135°). Botões de ângulo e controle de comprimento no painel.
- Comece o traço da caneta ou do marcador colado na borda da régua (até uns 30 px de distância): o traço fica reto e seguindo a régua, limitado ao comprimento dela.
- A escala é aproximada (1 cm ≈ 63 px de tela).
