// Roda no GitHub Actions depois de "npx cap add android".
// 1) Faz o app aparecer em "Abrir com" quando você toca num PDF (Chrome, Arquivos...)
// 2) Troca o MainActivity para entregar o PDF recebido ao app web.
const fs = require('fs');
const path = require('path');

const cfg = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8'));
const appId = cfg.appId;
const base = path.join('android', 'app', 'src', 'main');

// ---------- AndroidManifest ----------
const mf = path.join(base, 'AndroidManifest.xml');
let xml = fs.readFileSync(mf, 'utf8');
if (!xml.includes('application/pdf')) {
  const filters = `
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="content" android:mimeType="application/pdf" />
                <data android:scheme="file" android:mimeType="application/pdf" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="application/pdf" />
            </intent-filter>
        `;
  if (!xml.includes('</activity>')) throw new Error('Manifest sem </activity>');
  xml = xml.replace('</activity>', filters + '</activity>');
  fs.writeFileSync(mf, xml);
}

// ---------- MainActivity ----------
const dir = path.join(base, 'java', ...appId.split('.'));
fs.mkdirSync(dir, { recursive: true });
const java = `package ${appId};

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import org.json.JSONObject;

public class MainActivity extends BridgeActivity {
    private volatile String pending = null;

    public class IntentBridge {
        @JavascriptInterface
        public String getPending() {
            String p = pending;
            pending = null;
            return p == null ? "" : p;
        }

        @JavascriptInterface
        public String readB64(String path) {
            try {
                File f = new File(path).getCanonicalFile();
                String root = getCacheDir().getCanonicalPath();
                if (!f.getPath().startsWith(root)) return "";
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                try (InputStream in = new FileInputStream(f)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                }
                return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getBridge().getWebView().addJavascriptInterface(new IntentBridge(), "AndroidIntent");
        handle(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    @SuppressWarnings("deprecation")
    private void handle(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(action)) {
            uri = intent.getData();
        } else if (Intent.ACTION_SEND.equals(action)) {
            uri = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
        }
        if (uri == null) return;
        final Uri u = uri;
        intent.setAction(Intent.ACTION_MAIN);
        intent.setData(null);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String name = "Prova.pdf";
                    Cursor c = getContentResolver().query(u, null, null, null, null);
                    if (c != null) {
                        try {
                            int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                            if (i >= 0 && c.moveToFirst()) {
                                String n = c.getString(i);
                                if (n != null && n.length() > 0) name = n;
                            }
                        } finally {
                            c.close();
                        }
                    }
                    File[] old = getCacheDir().listFiles();
                    if (old != null) {
                        for (File f : old) {
                            if (f.getName().startsWith("in_") && f.getName().endsWith(".pdf")) f.delete();
                        }
                    }
                    File out = new File(getCacheDir(), "in_" + System.currentTimeMillis() + ".pdf");
                    try (InputStream in = getContentResolver().openInputStream(u);
                         OutputStream os = new FileOutputStream(out)) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                    }
                    JSONObject o = new JSONObject();
                    o.put("path", out.getAbsolutePath());
                    o.put("name", name);
                    pending = o.toString();
                } catch (Exception e) {
                    // ignora: o app simplesmente não recebe o arquivo
                }
            }
        }).start();
    }
}
`;
fs.writeFileSync(path.join(dir, 'MainActivity.java'), java);
console.log('Android patch OK ->', dir);
