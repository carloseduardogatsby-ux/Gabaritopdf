# Gabarito Deck PDF

App (Capacitor) para estudar provas em PDF com gabarito, anotações e resultado.

- Toque num PDF baixado no Chrome e escolha **Gabarito Deck PDF** em "Abrir com".
- 🎨 cor do papel ajustável (matiz + intensidade) · 🌙/☀️ modo noturno e claro.
- 🔍 zoom livre (dois dedos) ou ± zoom por botões.
- Alternativas: toque na letra e confirme no ✓.
- Barra flutuante móvel: arraste pela alça no topo.

O APK é gerado pelo GitHub Actions (`.github/workflows/build-apk.yml`).
`patch-android.js` ajusta o projeto Android (Abrir com…). `debug.keystore` mantém a mesma assinatura entre builds.
